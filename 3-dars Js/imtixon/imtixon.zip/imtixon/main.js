// // 1-misol
// let a = +prompt("1-son kiritn")
// let b = +prompt("2-son kiritn")
// if(a>b){
//     console.log(a + " eng kotasi",b + " eng kichigi");
// }else if(b>a){
//     console.log(b + " eng kotasi", a + " eng kichigi");
// }else{
//     console.log("bular teng");
// }


// // 2-misol
// let a = +prompt("a son kiritn")
// let b = +prompt("b son kiritn")
// //juft uchun
// let x = 0
// for(i=a ; i<b ;i++){
//     if(i % 2==0){
//         x = x+i
//         console.log(x + " juft son");
//     }
// }
// //toq uchun
// for(i=a ; i<b ;i++){
//     if(i % 2!==0){
//         console.log(i + " toq son");
//     }
// }



// // 3-misol
// let a = prompt("3 xonali son kiritn")
// let d=Math.floor(a/100)%10
// let c=Math.floor(a/10)%10
// let x=Math.floor(a%10)
// console.log(x*100 + c*10 +d + " orin almashgan xolati");


// 4-misol
// function box(){
//     let a = +prompt("a ni qiymati")
//     let b = +prompt("b ni qiymati")
//     console.log(a**b);
// }
// box()


// // 5-misol
// let a = prompt("soz kiritn")
// if(a.startsWith("Assalomu alaykum")){
//     alert("Xush kelibsiz")
// }else{
//     alert("Tizimga kirish mumkin emas")
// }


// 8-misol
// 1-usul
// let a = prompt("id kiritn")
// data.map(x=>{
//     if(a==x.id){
//         console.log(x);
//     }
// })

// 2-usul
// data.map(a=>{
//     if(a.year>=2002){
//         console.log(a);
//     }
// })


// 3-usul
// data.map(a=>{
//     if(a.genres==  "Comedy"){
//         console.log(a);
//     }
// })

// // 4-usul
// let x = prompt("gener kirirtn")
// data.map(i=>{
//    if(x ==i.genres){
//     console.log(x);
//    }
// })

