// let  a = +prompt( "1-son" )
// let  b = +prompt( "2-son" )
// console.log( a+b , a * b , a ** b , );
// //1-vaizfa



// let a = 2
// let b = 4
// let c = 6
// let d =c //6
// let v =b //4
// b=a//2
// a=d//6
// c=v//4
// console.log( a + "a" );
// console.log( b +"b" );
// console.log( c + "c" );
// //2-vazifa




// let a = prompt ( "kg / tonnaga otkazish")
// console.log( a / 1000)
// //3-vazifa




let a = prompt ("sekundan soatga otish" )
console.log( a / 3600 +"soat" , a * 3600  +"sekund")
//4-vazifa


// let a = 1440
// console.log( a * 3600)





